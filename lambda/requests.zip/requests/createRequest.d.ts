import type { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=createRequest.d.ts.map
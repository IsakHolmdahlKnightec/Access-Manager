import type { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=addMoreInfo.d.ts.map